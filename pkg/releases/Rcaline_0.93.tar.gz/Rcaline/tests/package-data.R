library(Rcaline)
highways.shp <- system.file("extdata", "WestOakland", "highways.shp", package = "Rcaline")