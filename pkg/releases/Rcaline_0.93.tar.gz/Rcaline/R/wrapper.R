#
# Native code (Fortran) wrapper function
#

.caline3.receptor_totals <- function(
	XR, YR, ZR,
	XL1, YL1, XL2, YL2, WL, HL, TYP, VPHL, EFL,
	UM, BRGM, CLASM, MIXHM,
	ATIM, Z0, VS = 0.0, VD = 0.0, MAXDIST = 1e5
) {	

	# Receptor specifications
	NR <- as.integer(length(XR))
	stopifnot( all.equal(NR, length(YR), length(ZR)) )
	if( any(is.na(XR)) )
		stop("All receptor X coordinates must be specified.")		
	if( any(is.na(YR)) )
		stop("All receptor Y coordinates must be specified.")
	if( any(is.na(ZR)) )
		stop("All receptor Z coordinates must be specified.")

	# Link specifications
	NL <- as.integer(length(XL1))
	stopifnot( all.equal(NL, length(YL1), length(XL2), length(YL2),
		length(WL), length(HL), length(TYP), length(VPHL), length(EFL)) )	
	if( any(is.na(WL)) )
		stop("All link widths must be specified.")
	if( any(is.na(HL)) )
		stop("All link heights must be specified.")
	if( any(is.na(TYP)) )
		stop("All link classifications must be specified.")
	if( any(is.na(VPHL)) )
		stop("All links must have a non-NULL flow (vehicles per hour).") 
	if( any(is.na(EFL)) )
		stop('All links must have a non-NULL emission factor (grams per vehicle-mile).') 
	
	# Receptor specifications
	NM <- as.integer(length(UM))
	stopifnot( all.equal(NM, length(BRGM), length(CLASM), length(MIXHM)) )
	if( any(is.na(UM)) )
		stop("All wind speeds must be specified.")		
	if( any(is.na(BRGM)) )
		stop("All wind bearings must be specified.")
	if( any(is.na(CLASM)) )
		stop("All stability classes must be specified.")
	if( any(is.na(MIXHM)) )
		stop("All mixing heights must be specified.")
			
	# Coerce type classifications to integers 
	# (can't pass characters to .Fortran() with DUP = FALSE )
	if(is.character(TYP)) {
		clas.lookup <- list(AG=0, BR=1, FL=2, DP=3, 
			`At Grade`=0, `Bridge`=1, `Fill`=2, `Depressed`=3)
		#print(clas.lookup)
		#print(TYP)
		#print(clas.lookup[TYP])
		NTYP <- as.integer(clas.lookup[TYP])
	} else if(is.integer(TYP)) {
		NTYP <- TYP
	} else {
		stop('TYP argument must be character or integer')
	}
	
	# Meteorology specifications
	if( any(UM < 1.0) )
		stop("Wind speeds less than 1.0 m/s are not valid input for the CALINE3 model.") 
	if( any(BRGM < 0) || any(BRGM > 360) )
		stop("Wind bearing must be in [0, 360].")
	if( any(CLASM < 1) || any(CLASM > 6) )
		stop("Stability class must be an integer between 1 and 6 (inclusive).")
	if( any(MIXHM < 0) )
		stop("Mixing height cannot be negative.")
		
	# TODO: more rigorous type checking
	stopifnot(lapply(list(XR, YR, ZR), is.numeric) == TRUE)
	stopifnot(lapply(list(XL1, YL1, XL2, YL2, WL, HL, NTYP, VPHL, EFL), is.numeric) == TRUE)
	stopifnot(lapply(list(UM, BRGM, CLASM, MIXHM), is.numeric) == TRUE)
	
	# Call native code, allocating array C to hold results
	array.shape <- c(NR,NM)
	returned_data <- .Fortran(
			"CALINE3_HOURLY_RECEPTOR_TOTALS", 
			NR, XR, YR, ZR,
			NL, XL1, YL1, XL2, YL2, WL, HL, NTYP, VPHL, EFL,
			NM, UM, BRGM, CLASM, MIXHM,
			ATIM, Z0, VS, VD, MAXDIST,
			C = as.single(array(0.0, dim=array.shape)),
			PACKAGE = "Rcaline"
	)
	
	# Reshape and return results
	predicted <- returned_data$C
	dim(predicted) <- array.shape
	return(predicted)
	
}
