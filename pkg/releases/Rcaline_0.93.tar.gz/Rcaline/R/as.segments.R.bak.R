as.segments.Line <- function(spobj) {
	vertices <- coordinates(spobj)	# a 2-column (?) matrix
	stopifnot(ncol(vertices) == 2)
	n <- nrow(vertices)				# the number of vertices
	x0y0 <- matrix(vertices[1:(n-1),], ncol=2)
	x1y1 <- matrix(vertices[2:n,], ncol=2)
	segs <- cbind(x0y0, x1y1)
	colnames(segs) <- c('x0','y0','x1','y1')
	return(segs)
}

as.segments.Lines <- function(spobj) {
	do.call(rbind, lapply(spobj@Lines, as.segments))
}

as.segments.SpatialLines <- function(spobj) {
	seg.list <- lapply(spobj@lines, as.segments)
	do.call(rbind, seg.list)
}

as.segments.SpatialLinesDataFrame <- function(spobj) {
	seg.list <- lapply(spobj@lines, as.segments)
	segs <- do.call(rbind, seg.list)
	seg.lengths <- lapply(seg.list, nrow)
	ids <- unlist(mapply(rep, 1:nrow(spobj), seg.lengths))
	segs.df <- data.frame(ID=ids, do.call(rbind, seg.list))
	merged.df <- merge(segs.df, spobj@data, by.x='ID', by.y='row.names')
	merged.df$ID <- NULL
	return(merged.df)
}

as.segments <- function(spobj) stop(paste("Sorry, I don't know what to do with a", class(spobj)))
setGeneric("as.segments")
setMethod("as.segments", "SpatialLinesDataFrame", as.segments.SpatialLinesDataFrame)
setMethod("as.segments", "SpatialLines", as.segments.SpatialLines)
setMethod("as.segments", "Lines", as.segments.Lines)
setMethod("as.segments", "Line", as.segments.Line)